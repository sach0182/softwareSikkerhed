﻿using System;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Collections.Generic;
using System.Runtime.Intrinsics.X86;
using System.Security.Cryptography;
using System.IO;

namespace softwareSikkerhedClient
{
    
    class Client
    {
        static void Main(string[] args)
        {
            //Client cli = new Client();
            Encryption enc = new Encryption();
        }
    }
}
class Encryption
{
    public int sharedKey;
    public string clientKey;
    public int privatKey = 2;
    public int communKey = 11;

    public Encryption()
    {
        //con
        TcpClient client = new TcpClient();

        int port = 13356;
        IPAddress ip = IPAddress.Parse("127.0.0.1");
        IPEndPoint endPoint = new IPEndPoint(ip, port);

        client.Connect(endPoint);
        NetworkStream stream = client.GetStream();

        diffie(stream);//______________________________________________kalder funktion til at sende diffie
        ReceiveDiffie(stream);//_______________________________________kalder finktion til at modtage diffie

        //______________________________
        bool isRunning = true;
        while (isRunning) {
            ReceiveMessage(stream);

            Console.Write("Write your message here: ");
            string text = Console.ReadLine();

            byte[] bytes = Encoding.UTF8.GetBytes(text + sharedKey);
            byte key = 255;
            EncryptByte(bytes, key, stream);
        }
    }
    //_____________________________________________________________________sener diffie
    public void diffie(NetworkStream stream)
    {
        byte key = 255;
        int calClientKey = privatKey + communKey;
        clientKey = calClientKey.ToString();
        byte[] bytes = Encoding.UTF8.GetBytes(clientKey);
        for (int i = 0; i < bytes.Length; i++)
        {
            int change = i + key;
            while (change + bytes[i] > 255) change -= 256;
            bytes[i] += (byte)change;
        }

        stream.Write(bytes, 0, bytes.Length);
    }
    //___________________________________________________________________udregner diffie
    public void diffieCal(int serverId) {
        sharedKey = serverId + privatKey;
        Console.WriteLine("\nudregning fællsenøgle: " + sharedKey);
    
    }
    //_____________________________________________________________________dekryptere diffie
    public void DecryptDiffie(byte[] bytes, byte key, int numberOfBtyes)
    {
        for (int i = 0; i < numberOfBtyes; i++)
        {
            int change = i + key;
            while (change - bytes[i] < 0) change += 256;
            bytes[i] -= (byte)change;
        }
        string toPrint = Encoding.UTF8.GetString(bytes);
        int myint = Int32.Parse(toPrint);
        Console.WriteLine("\ndecrypteret server nøgle: " + myint);
        diffieCal(myint);
    }
    //____________________________________________________________________________modtager diffie
    public async void ReceiveDiffie(NetworkStream stream)
    {

        byte[] bytes = new byte[256];
        byte key = 255;
        int numberOfBytesRead = await stream.ReadAsync(bytes, 0, 256);
        string receivedMessage = Encoding.UTF8.GetString(bytes, 0, numberOfBytesRead);
        Console.Write("\nkrypteret server nøgle: " + receivedMessage);
        DecryptDiffie(bytes, key, numberOfBytesRead);
    }

    //_______________________________________________________________________________________________________________________

    public void EncryptByte(byte[] bytes, byte key, NetworkStream stream)
    {
        int encrypSharedKey = sharedKey;// shared key = diffie hellman fællesnøglen mellem server/client indkuporeres i kryptering
        for (int i = 0; i < bytes.Length; i++)
        {
            int change = i + key;
            while (change + bytes[i] > 255) change -= 256;
            bytes[i] += (byte)change;
        }

        stream.Write(bytes, 0, bytes.Length);
    }

    //_______________________________________________________________________________________________________________________
    
    public void DecryptByte(byte[] bytes, byte key, int numberOfBtyes)
    {
        int decryptSharedKey = sharedKey; // shared key = diffie hellman fællesnøglen mellem server/client indkuporeres i decrypteringen
        for (int i = 0; i < numberOfBtyes; i++)
        {
            int change = i + key;
            while (change - bytes[i] < 0) change += 256;
            bytes[i] -= (byte)change;
        }
        string toPrint = Encoding.UTF8.GetString(bytes);
        toPrint = toPrint.Remove(numberOfBtyes-2);

        Console.WriteLine("\nnu er det ikke krypteret: " + toPrint);
    }

    //_______________________________________________________________________________________________________________________

    public async void ReceiveMessage(NetworkStream stream)
    {

        byte[] bytes = new byte[256];
        byte key = 255;
        int numberOfBytesRead = await stream.ReadAsync(bytes, 0, 256);
        string receivedMessage = Encoding.UTF8.GetString(bytes, 0, numberOfBytesRead);
        Console.Write("\nsådan ser det ud ikke decrypteret: " + receivedMessage);
        DecryptByte(bytes, key, numberOfBytesRead);
    }
}



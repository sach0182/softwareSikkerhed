﻿using System;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Collections.Generic;
using System.Runtime.Intrinsics.X86;
using System.Security.Cryptography;
using System.IO;
using Aes = System.Security.Cryptography.Aes;

namespace softwareSikkerhedServer
{
    class Server
    {
        
        static void Main(string[] args)
        {
            //Server srv = new Server();
            Encryption enc = new Encryption();
        }
    }
}
class Encryption
{
    public List<TcpClient> clients = new List<TcpClient>();
    public int sharedKey;
    public string serverKey;
    public int privatKey = 1;
    public int communKey = 11;

    public Encryption()
    {
        IPAddress ip = IPAddress.Any;
        int port = 13356;
        IPEndPoint localEndpoint = new IPEndPoint(ip, port);
        TcpListener listener = new TcpListener(localEndpoint);
        listener.Start();

        TcpClient client = listener.AcceptTcpClient();
        NetworkStream stream = client.GetStream();

        diffie(stream); //____________________________________kalder send diffie funktion
        ReceiveDiffie(stream);//______________________________kalder modtag diffie funktion

        bool isRunning = true;
        while (isRunning) {
            ReceiveMessage(stream);
            Console.Write("Write your message here: ");
            string text = Console.ReadLine();

            byte[] bytes = Encoding.UTF8.GetBytes(text+sharedKey);

            byte key = 255;
            EncryptByte(bytes, key, stream);
        }
    }
    //_____________________________________________________________________________sender diffie
    public void diffie(NetworkStream stream)
    {
        byte key = 255;
        int calServerKey = privatKey + communKey;
        serverKey = calServerKey.ToString();
        byte[] bytes = Encoding.UTF8.GetBytes(serverKey);
        for (int i = 0; i < bytes.Length; i++)
        {
            int change = i + key;
            while (change + bytes[i] > 255) change -= 256;
            bytes[i] += (byte)change;
        }

        stream.Write(bytes, 0, bytes.Length);
    }
    //_____________________________________________________________________________udregner vores fællesnævner 
    public void diffieCal(int serverId)
    {
        sharedKey = serverId + privatKey;
        Console.WriteLine("\nudregning af fællesnøglen: " + sharedKey);
    }
    //____________________________________________________________________________Dekryptere diffi så vi kan se den
    public void DecryptDiffie(byte[] bytes, byte key, int numberOfBtyes)
    {
        for (int i = 0; i < numberOfBtyes; i++)
        {
            int change = i + key;
            while (change - bytes[i] < 0) change += 256;
            bytes[i] -= (byte)change;
        }
        string toPrint = Encoding.UTF8.GetString(bytes);
        int myint = Int32.Parse(toPrint);
        Console.WriteLine("\nserver nøgle dekrypteret: " + myint);
        diffieCal(myint);
    }
    //______________________________________________________________________________________________________________modtager diffie
    public async void ReceiveDiffie(NetworkStream stream)
    {

        byte[] bytes = new byte[256];
        byte key = 255;
        int numberOfBytesRead = await stream.ReadAsync(bytes, 0, 256);
        string receivedMessage = Encoding.UTF8.GetString(bytes, 0, numberOfBytesRead);
        Console.Write("\nserver nøgle krypteret: " + receivedMessage);
        DecryptDiffie(bytes, key, numberOfBytesRead);
    }

    //______________________________________________________________________________________________________________besked funktioner 
    //______________________________________________________________________________________________________________enncrypt
    public void EncryptByte(byte[] bytes, byte key, NetworkStream stream)
    {
        int encrypSharedKey = sharedKey;// shared key = diffie hellman fællesnøglen mellem server/client indkuporeres i kryptering
        for (int i = 0; i < bytes.Length; i++)
        {
            int change = i + key;
            while (change + bytes[i] > 255) change -= 256;
            bytes[i] += (byte)change;
        }
        
        stream.Write(bytes, 0, bytes.Length);
    }
    //______________________________________________________________________________________________________________decrypt
    public void DecryptByte(byte[] bytes, byte key, int numberOfBytes)
    {
        int decryptSharedKey = sharedKey; // shared key = diffie hellman fællesnøglen mellem server/client indkuporeres i decrypteringen
        for (int i = 0; i < numberOfBytes; i++)
        {
            int change = i + key;
            while (change - bytes[i] < 0) change += 256;
            bytes[i] -= (byte)change;
        }
        string toPrint = Encoding.UTF8.GetString(bytes);
        toPrint = toPrint.Remove(numberOfBytes-2);
        
        Console.WriteLine("\nsådan ser det ud når det er decryptet: " + toPrint);
    }
    //______________________________________________________________________________________________________________receive
    public async void ReceiveMessage(NetworkStream stream)
    {
        byte[] bytes = new byte[256];
        byte key = 255;

        int numberOfBytesRead = await stream.ReadAsync(bytes, 0, 256);
        string receivedMessage = Encoding.UTF8.GetString(bytes, 0, numberOfBytesRead);

        Console.Write("\ndette er hvad programmet modtager: " + receivedMessage);
        DecryptByte(bytes, key, numberOfBytesRead);
    }
}

